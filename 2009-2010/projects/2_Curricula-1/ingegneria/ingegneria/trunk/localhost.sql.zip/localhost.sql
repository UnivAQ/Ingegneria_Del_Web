-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb1ubuntu0.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generato il: 15 Giu, 2010 at 03:10 PM
-- Versione MySQL: 5.0.67
-- Versione PHP: 5.2.6-2ubuntu4.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `job`
--
CREATE DATABASE `job` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `job`;

-- --------------------------------------------------------

--
-- Struttura della tabella `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id_account` int(10) NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `tipologia` int(1) NOT NULL,
  PRIMARY KEY  (`id_account`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dump dei dati per la tabella `account`
--

INSERT INTO `account` (`id_account`, `username`, `password`, `email`, `tipologia`) VALUES
(3, 'marco', 'marco', '', 1),
(4, 'paolo', 'paolo', 'paolo@email.it', 1),
(5, 'ricci11', 'ricci11', 'email', 1),
(6, 'azienda', 'azienda', 'aziendaprova@email.it', 2),
(7, 'ettore', 'ettore', 'ettore@email.it', 1),
(8, 'carvin', 'carvin', 'carvin@info.it', 2),
(15, 'prova2', 'prova2', 'prova2@email.it', 1),
(16, 'prova3', 'prova3', 'prova3@email.it', 1),
(17, 'a', 'a', 'a', 1),
(18, 'b', 'b', 'b', 1),
(19, 'paolo1', 'ciao', 'ca@ca.it', 1),
(20, 'franco', 'troiano', 'franco@troiano.pe.it', 1),
(21, 'italtel', 'italtel', 'staff@italtel.it', 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `anagrafica`
--

CREATE TABLE IF NOT EXISTS `anagrafica` (
  `id_anagrafica` int(10) NOT NULL auto_increment,
  `id_curriculum` int(10) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `sesso` varchar(1) NOT NULL,
  `dataNascita` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `indirizzo` varchar(100) NOT NULL,
  `provincia` varchar(2) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  PRIMARY KEY  (`id_anagrafica`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dump dei dati per la tabella `anagrafica`
--

INSERT INTO `anagrafica` (`id_anagrafica`, `id_curriculum`, `nome`, `cognome`, `sesso`, `dataNascita`, `email`, `indirizzo`, `provincia`, `telefono`) VALUES
(22, 43, 'alessandro', 'savini', 'M', '1988-07-01', 'email', 'vicino al supermercato ', 'TE', '123'),
(21, 42, 'Valentina', 'Proietti', 'F', '1988-05-27', 'valentina.proietti@hotmail.it', 'via clemente de cesaris 13', 'TE', '234523432423'),
(20, 41, 'marco', 'dagostino', 'M', '1988-08-29', 'marco@email.it', 'via ciao', 'PE', '123423'),
(23, 44, 'paolo', 'dettorre', 'M', '1989-01-01', 'paolo@dettorre.it', 'via pescara', 'CH', '3282828199'),
(24, 44, 'paolo', 'dettorre', 'M', '1989-01-01', 'paolo@dettorre.it', 'via pescara', 'CH', '3282828199'),
(25, 44, 'paolo', 'dettorre', 'M', '1989-01-01', 'poiupoiu@skdjhf.it', 'oiuyoiuy', 'BA', '9876'),
(26, 47, 'paolo', 'ilhglkjgh', 'M', '1989-01-01', 'ljkhlk@ghkjhg.it', 'lujhlkjh', 'NA', '8765'),
(27, 48, 'franco', 'troiano', 'M', '1988-04-13', 'franco@troiano.pe.it', 'via pratelle 30 pianella', 'PE', '3289251343');

-- --------------------------------------------------------

--
-- Struttura della tabella `aziende`
--

CREATE TABLE IF NOT EXISTS `aziende` (
  `id_aziende` int(10) NOT NULL auto_increment,
  `id_account` int(10) NOT NULL,
  `ragioneSociale` varchar(255) NOT NULL,
  `piva` varchar(11) NOT NULL,
  PRIMARY KEY  (`id_aziende`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dump dei dati per la tabella `aziende`
--

INSERT INTO `aziende` (`id_aziende`, `id_account`, `ragioneSociale`, `piva`) VALUES
(1, 6, 'azienda prova', '1234'),
(2, 8, 'carvin engineering', '1234'),
(3, 21, 'italtel', '1234');

-- --------------------------------------------------------

--
-- Struttura della tabella `capacita`
--

CREATE TABLE IF NOT EXISTS `capacita` (
  `id_capacita` int(10) NOT NULL auto_increment,
  `id_curriculum` int(10) NOT NULL,
  `capacita` varchar(255) NOT NULL,
  PRIMARY KEY  (`id_capacita`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dump dei dati per la tabella `capacita`
--

INSERT INTO `capacita` (`id_capacita`, `id_curriculum`, `capacita`) VALUES
(11, 41, 'disegno cad'),
(12, 41, 'pacchetto microsoft office'),
(13, 42, 'autocad'),
(14, 42, 'ss'),
(17, 47, 'sadfasdfa'),
(18, 47, 'asdf'),
(19, 48, 'programmazione');

-- --------------------------------------------------------

--
-- Struttura della tabella `curriculum`
--

CREATE TABLE IF NOT EXISTS `curriculum` (
  `id_curriculum` int(10) NOT NULL auto_increment,
  `id_account` int(10) NOT NULL,
  `numLingue` int(3) NOT NULL,
  `numIstruzione` int(3) NOT NULL,
  `numCapacita` int(3) NOT NULL,
  `numEsperienze` int(3) NOT NULL,
  `dataModifica` int(20) NOT NULL,
  PRIMARY KEY  (`id_curriculum`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dump dei dati per la tabella `curriculum`
--

INSERT INTO `curriculum` (`id_curriculum`, `id_account`, `numLingue`, `numIstruzione`, `numCapacita`, `numEsperienze`, `dataModifica`) VALUES
(41, 16, 2, 1, 2, 1, 1275923173),
(42, 17, 0, 2, 0, 0, 1276445372),
(43, 18, 1, 1, 1, 1, 1275925659),
(47, 4, 1, 1, 2, 1, 1276178760),
(48, 20, 2, 1, 1, 1, 1276179014);

-- --------------------------------------------------------

--
-- Struttura della tabella `esperienze`
--

CREATE TABLE IF NOT EXISTS `esperienze` (
  `id_esperienze` int(10) NOT NULL auto_increment,
  `id_curriculum` int(10) NOT NULL,
  `datore` varchar(255) NOT NULL,
  `incarico` varchar(255) NOT NULL,
  `periodo` varchar(25) NOT NULL,
  PRIMARY KEY  (`id_esperienze`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dump dei dati per la tabella `esperienze`
--

INSERT INTO `esperienze` (`id_esperienze`, `id_curriculum`, `datore`, `incarico`, `periodo`) VALUES
(6, 41, 'di quinzio', 'geometra', '2007-2008'),
(9, 47, 'asdfa', 'asdfada', 'sdfa'),
(10, 48, 'pece dino', 'elettricista', '2005');

-- --------------------------------------------------------

--
-- Struttura della tabella `istruzione`
--

CREATE TABLE IF NOT EXISTS `istruzione` (
  `id_istruzione` int(10) NOT NULL auto_increment,
  `id_curriculum` int(10) NOT NULL,
  `titolo` varchar(255) NOT NULL,
  `data` varchar(25) NOT NULL,
  `istituzione` varchar(255) NOT NULL,
  `voto` int(3) NOT NULL,
  `tipologia` int(1) NOT NULL,
  PRIMARY KEY  (`id_istruzione`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dump dei dati per la tabella `istruzione`
--

INSERT INTO `istruzione` (`id_istruzione`, `id_curriculum`, `titolo`, `data`, `istituzione`, `voto`, `tipologia`) VALUES
(7, 41, 'geometra', '2007', 'mantone pescara', 68, 1),
(8, 42, 'geometra', '2008', 'mantone pescara', 0, 1),
(10, 43, 'a', '1', 'a', 0, 0),
(11, 42, 'kjhkjh', 'kjhkjh', 'kjhkjh', 67, 3),
(12, 47, 'sadgf', 'dwf', 'dsfsd', 231, 1),
(13, 48, 'Perito Capotecnico elettronica e telecomunicazioni', '2007', 'Itis A.Volta Pescara', 100, 1),
(14, 42, 'mediatrice linguistica', '2009', 'università di l aquila', 90, 2);

-- --------------------------------------------------------

--
-- Struttura della tabella `lingue`
--

CREATE TABLE IF NOT EXISTS `lingue` (
  `id_lingue` int(10) NOT NULL auto_increment,
  `id_curriculum` int(10) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `livelloParlato` int(1) NOT NULL,
  `livelloScritto` int(1) NOT NULL,
  PRIMARY KEY  (`id_lingue`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dump dei dati per la tabella `lingue`
--

INSERT INTO `lingue` (`id_lingue`, `id_curriculum`, `nome`, `livelloParlato`, `livelloScritto`) VALUES
(8, 41, 'inglese', 1, 1),
(9, 41, 'francese', 1, 1),
(11, 42, 'inglese1', 1, 1),
(12, 42, 'francese', 1, 1),
(13, 44, 'inglese', 1, 1),
(14, 44, 'francese', 1, 1),
(15, 44, 'inglese', 1, 1),
(16, 44, 'francese', 1, 1),
(17, 47, 'asdasd', 1, 1),
(18, 48, 'inglese', 1, 1),
(19, 48, 'francese', 1, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `ricerca`
--

CREATE TABLE IF NOT EXISTS `ricerca` (
  `id_ricerca` int(10) NOT NULL auto_increment,
  `id_azienda` int(10) NOT NULL,
  `etaMin` int(3) NOT NULL,
  `etaMax` int(3) NOT NULL,
  `sesso` varchar(3) NOT NULL,
  `lingua1` varchar(20) NOT NULL,
  `lingua2` varchar(20) NOT NULL,
  `lingua3` varchar(20) NOT NULL,
  `tipologia` varchar(1) NOT NULL,
  `denominazione` varchar(255) NOT NULL,
  `partTime` tinyint(1) NOT NULL,
  `fullTime` tinyint(1) NOT NULL,
  `determinato` tinyint(1) NOT NULL,
  `indeterminato` tinyint(1) NOT NULL,
  `dirigente` tinyint(1) NOT NULL,
  `subordinato` tinyint(1) NOT NULL,
  `lavoroEstero` tinyint(1) NOT NULL,
  `soggiornoEstero` tinyint(1) NOT NULL,
  `provincia` varchar(2) NOT NULL,
  `data` int(20) NOT NULL,
  PRIMARY KEY  (`id_ricerca`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dump dei dati per la tabella `ricerca`
--

INSERT INTO `ricerca` (`id_ricerca`, `id_azienda`, `etaMin`, `etaMax`, `sesso`, `lingua1`, `lingua2`, `lingua3`, `tipologia`, `denominazione`, `partTime`, `fullTime`, `determinato`, `indeterminato`, `dirigente`, `subordinato`, `lavoroEstero`, `soggiornoEstero`, `provincia`, `data`) VALUES
(36, 8, 0, 99, 'MF', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, '', 1276445380);

-- --------------------------------------------------------

--
-- Struttura della tabella `tipoImpiego`
--

CREATE TABLE IF NOT EXISTS `tipoImpiego` (
  `id_tipoImpiego` int(10) NOT NULL auto_increment,
  `id_curriculum` int(10) NOT NULL,
  `provincia` varchar(2) NOT NULL,
  `partTime` tinyint(1) NOT NULL,
  `fullTime` tinyint(1) NOT NULL,
  `determinato` tinyint(1) NOT NULL,
  `indeterminato` tinyint(1) NOT NULL,
  `dirigente` tinyint(1) NOT NULL,
  `subordinato` tinyint(1) NOT NULL,
  `lavoroEstero` tinyint(1) NOT NULL,
  `soggiornoEstero` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id_tipoImpiego`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dump dei dati per la tabella `tipoImpiego`
--

INSERT INTO `tipoImpiego` (`id_tipoImpiego`, `id_curriculum`, `provincia`, `partTime`, `fullTime`, `determinato`, `indeterminato`, `dirigente`, `subordinato`, `lavoroEstero`, `soggiornoEstero`) VALUES
(11, 41, 'CH', 0, 1, 0, 1, 0, 0, 1, 1),
(12, 42, 'TE', 0, 1, 0, 1, 0, 1, 0, 0),
(13, 43, 'BS', 1, 1, 1, 1, 1, 1, 1, 1),
(14, 44, '', 0, 0, 0, 0, 0, 0, 0, 0),
(15, 47, 'BS', 0, 0, 0, 0, 1, 1, 0, 0),
(16, 48, 'PE', 0, 1, 0, 0, 0, 0, 0, 0);
--
-- Database: `tdw`
--
CREATE DATABASE `tdw` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `tdw`;

-- --------------------------------------------------------

--
-- Struttura della tabella `cat_macrocat`
--

CREATE TABLE IF NOT EXISTS `cat_macrocat` (
  `id_categoria` int(5) NOT NULL,
  `id_macrocategoria` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dump dei dati per la tabella `cat_macrocat`
--

INSERT INTO `cat_macrocat` (`id_categoria`, `id_macrocategoria`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 2),
(5, 2),
(7, 4),
(8, 3),
(9, 3),
(10, 3),
(11, 3);

-- --------------------------------------------------------

--
-- Struttura della tabella `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `id_categoria` int(5) NOT NULL auto_increment,
  `nome` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_categoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Dump dei dati per la tabella `categorie`
--

INSERT INTO `categorie` (`id_categoria`, `nome`) VALUES
(1, 'Macchinette Digitali'),
(3, 'iPhone'),
(4, 'Aria Condizionata'),
(6, ''),
(8, '1'),
(9, '2'),
(10, '3');

-- --------------------------------------------------------

--
-- Struttura della tabella `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id_feedback` int(5) NOT NULL auto_increment,
  `id_prodotto` int(5) NOT NULL,
  `id_utente` int(5) NOT NULL,
  `titolo` varchar(50) collate utf8_unicode_ci NOT NULL,
  `feedback` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_feedback`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dump dei dati per la tabella `feedback`
--

INSERT INTO `feedback` (`id_feedback`, `id_prodotto`, `id_utente`, `titolo`, `feedback`) VALUES
(1, 1, 1, 'Good Product', 'dopo tutto è un buon prodotto....\r\n\r\nalmeno penso...'),
(2, 1, 2, 'Non mi piace', 'Fa cacare'),
(3, 3, 1, 'prova feedback', 'invio feedback\r\n\r\nOK!\r\n\r\nHTML: &lt;br&gt;&lt;b&gt;ciao&lt;/b&gt;'),
(4, 6, 1, 'ok', 'ok\r\n');

-- --------------------------------------------------------

--
-- Struttura della tabella `gruppi`
--

CREATE TABLE IF NOT EXISTS `gruppi` (
  `id_gruppo` int(5) NOT NULL auto_increment,
  `nome` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_gruppo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dump dei dati per la tabella `gruppi`
--

INSERT INTO `gruppi` (`id_gruppo`, `nome`) VALUES
(1, 'Utenti'),
(2, 'Aziende'),
(3, 'Moderatori'),
(4, 'SuperMod'),
(5, 'Bloccati');

-- --------------------------------------------------------

--
-- Struttura della tabella `gruppi_servizi`
--

CREATE TABLE IF NOT EXISTS `gruppi_servizi` (
  `id_gruppo` int(5) NOT NULL,
  `id_servizio` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dump dei dati per la tabella `gruppi_servizi`
--

INSERT INTO `gruppi_servizi` (`id_gruppo`, `id_servizio`) VALUES
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 8);

-- --------------------------------------------------------

--
-- Struttura della tabella `macrocategorie`
--

CREATE TABLE IF NOT EXISTS `macrocategorie` (
  `id_macrocategoria` int(5) NOT NULL auto_increment,
  `nome` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_macrocategoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dump dei dati per la tabella `macrocategorie`
--

INSERT INTO `macrocategorie` (`id_macrocategoria`, `nome`) VALUES
(1, 'Elettronica'),
(3, 'a'),
(4, 'b');

-- --------------------------------------------------------

--
-- Struttura della tabella `prodotti`
--

CREATE TABLE IF NOT EXISTS `prodotti` (
  `id_prodotto` int(5) NOT NULL auto_increment,
  `id_categoria` int(5) NOT NULL,
  `id_utente` int(5) NOT NULL,
  `titolo` varchar(50) collate utf8_unicode_ci NOT NULL,
  `descrizione` text collate utf8_unicode_ci NOT NULL,
  `tipo_img` varchar(10) collate utf8_unicode_ci NOT NULL,
  `immagine` mediumblob NOT NULL,
  PRIMARY KEY  (`id_prodotto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dump dei dati per la tabella `prodotti`
--

INSERT INTO `prodotti` (`id_prodotto`, `id_categoria`, `id_utente`, `titolo`, `descrizione`, `tipo_img`, `immagine`) VALUES
(1, 3, 1, 'Canon PowerShot S90abc', 'Canon''s PowerShot S90 is marketed as an advanced compact camera, and reviewers are in general agreement that it achieves success within that class. The S90 has the same 10-megapixel sensor as Canon''s larger G11 camera (*Est. $475), and shares some of its advanced features, such as optical image stabilization, RAW file support and a wealth of automatic and manual controls and settings. However, reviewers find that the S90 sacrifices shooting speed in favor of image quality and customization. Optical zoom is just 3.8x, less than much of the competition, and there is no optical viewfinder. Some reviewers find the S90''s small size and cramped controls a little awkward, especially for those with big hands, though its matte black casing is well built and appropriately professional-looking. The biggest concern is the price, which critics maintain is higher than that of comparable, if less feature-laden, compact cameras.\r\n\r\nWe found a good sampling of reviews for the PowerShot S90. CNET and CNET (Asia) both provide evaluations from different reviewers, each of which brings his own perspective in succinct write-ups. Britain''s TrustedReviews.com also has a balanced, easily digested review. For those looking for a more technical discussion, Steves-Digicams.com offers a lengthy and well-documented discussion of the S90''s merits.', 'image/jpeg', 0x4749463839612c012f01d50000000000759b759d4e27764f27abb8a8ffff00333333caa581a27345565656ff0000f5f4f499cc99cdb39afed4aab79470bb0a0ae3b68a5e3e1fab835a85582ccccc00141414ffff6679766fca7348dfdedea19e964a4a4abd9e7f88b388cc66334d341abf9a74d0bcac996633ffcc99ae8c6aa4a110baba00d37b4fffff33424242666666b35a2d854221878787de9f7fad87628a5e33ffe0c0aa552ad58c67222120f0c295ff3333a07857fd56566f5943cdcac5aed7ae733c20d68359ffffff21f9040514003f002c000000002c012f010006ffc09f70482c1a8fc8a472c96c3a9fd0a8744aad5aafd8ac76cbed7abfe0b0784c2e9bcfe8b47acd6ebbdff0b87c4eafdbeff8bc7ecfeffbff808182838485868788898a8b4f2e188c90918209092a2a0692999a760b2b1a3f1c989ba3a469092b2b18189495068f773ba5b27ba92e0e17b8b929060635a2b3c0c152182eb9c61729c929351616c2cfd0492b1bb7c7c8cacacd9fd1dcd0b6d6d7d805e3cd09dde7b31822d5c6d8cae3051515002ee8f69a2bc5d6eec9f0f1f200ee0984a46f9f3b7fffe6051cc8d0903a70e1faf99327efc4c2861801752878ec20428a152c5ecc48520f06881e27823c616264c99774f281e3873061458b3073d2393953dcc7ff952744ea1cea2601cf8e29e1810c1914804ba250cb2430985429d0133d9e46dd0a66aa2e7e296a8e5b1a94a556ae68b5745a918003878812c5922d0b6043dabb5c5c50e2608917af1acc9a39758a0001c5188807a8187c16af63281a38e4b841b972650d82196bdeecf4c982c7a08b18e8ebb717e0661636c75000a1b5ebd69d43cb8e62c081eddbb81d10c09160c306ce836b40883dbb3893da9672df26c1bcb90d002b6b68364e5d890ab72a94db6eee1c0085ab42ab8b27a2622f07edba07337f6ef8aad31ae3e397df9b1d3781cc0998e300d01ee8e0f8f1a1c2d679b705961a00cd49b7d44aff85f11980dd6ce0085b95d8665a333870b75f023681d4ff2084b311b3c002180c78c985167047c273008cb5a042ce80181a061b8c3822852702b6406a2a3ae5e2821fca88573e36de38202f453aa51f093e8ec318458c09e9180645dab85795232a8960934e4510c360001127e5391a9867c989bd24a101955826806592242400809c080060410478e2e99442628ef9cc29aa0868668e4718d526076fda8820934c3a65830d79467000747cfa098d51c43420c3a69c6e7a5b0280d510cb10a960c981068966b9257300e0f0680483596051052df569e9283b10e342a7bccaa09d5f1c0821629122a890ea883b6c6900a38f6ac6010031547a6b29baf6da297ab7f1a2c20e04b850e525c766c92ab30732366948b64e1bff098d1a58cb29b6b971908fb745821beea25b3ecae260079c2b5263ea2242a3bb9ec2ab9c0ca904ea6679231a9b28becdea69aebfe1050c093104176c306e9c2acc17aa81d588250011c39ae760789e8b2e0004587c71c6be6e9c5ba7a8b48564666f92fc9ba4fdf6db65cad086a443ba2e1392c0ae04cbac5da76d9db8e3813947205dcf3d3b4535002ad00570d180609031bccdc1cb6907c6d6b0e360586a0000ac0084e0b6db1800d0c1d56599c535224727ad9d8a611bdc8b0535a25da406c94e8ac1038827def6db71d7dd523d7717b282deb9f1ade2722a42ca3600a8bea93600933e50420930940e43090fbced9409acb30e007c033db85527d62ae7ff9cbeb7ebfb6aa43c4bccb9e7a0875e020efbad30c1e988afdebaeb5b479e8706935f5bb9ee9af31e69bf6fbb4db5c41a746ee3e79302f0000cc43b45fce925bcbe3c051410edfc13a3a6214202ef2aa7aff579527d80db8927ae7dbf27f31eb2d636a9108c8f785fdaccf2063000f7bd4f0f9189d9f4aa973ffd618f7fa3cb20ea5207403d0970016b639b01c98783a1696681417a20206a63bbddf1cc82fb7b9be84867bad2a12e041d8cc07392b436ab197078c43321701ca84224c84e08473c430d30809bf554906ad9e3df0c4b3001e2591107c8c3e1daf46500c6b0087ba223e1b384259d1416310a0bd8061b7c611bdd3d3186524c5c064978452b96ff206e8eb201df500646d211af8b912040b0deb7831aacc8853dcb9e1c3548c53ad6913178d2237756e0a894ed2f8ce56bde199b80aa393483821734e0226b48472bc640074264190038a0431254ce8989c4e47e74b0c92f24310dcdb0640c11c7c8d239d28aa984dd0fb688ad15bdf0872404c02b6ab9882eba20913fa4a1e97e994933aaa00660d35c1f1ba9496606a25c72f42535f7a319bb1c61012c448f318f394318d4c59b911862b93803b925a4736fdabce00cdf09cf402e6688ae90c23d5bf8440c2ab39f393180045b98cf5da64f050885890108a4ce864693881145c768b2a94b646234a3ddd86831f3e9b6d14de0a3208d8606ea53514b467302ff944c2949063a3d97866074e4eba64c9fa1028dd5946718a4a24ef110bf9d7621013ba85f132ddacea11a55160b700101a4b71c8b5e14a24fed46896a21a112b565054b2de80f519ad54ccccb0522e8d684d8922307acf39863756a591791379889e042d583e63ee72a0c11780d661264c6cff44a3ab9f2f510d003ecf4f8a5cfd119f6b086e000fd3cd52b8632568ae97b2c6407215299ad477356dbe503c8bad943f8c290d463ce2b9d28d61090b6b48600cc065c883bcb21128a66846d2456801ade3dca7287bc5ed500d040cdead60fa8b953247f6b5b17020d0010286e0c8ebb89e4eab0b6cde59d0ba03b1cac1997ba7c48ee6f57fb590a028005b071ff41005e0b5e40840a9b7be38eee06031b0004e0bedf6d2f1924cb175144065122087080d52804b7f43701b68b133907a380063be5bef8d52f5155f157beb045506dc18eb6dc84811ce4a0697f31d0661aac00a758c003105e6f7e25dc050db800699c92ec6429a1d4f9d5c20534f0f0642c43e21e97f83d1e08728a73cbe235d0a8abbd9aac0c38b050db744c1511d0318f7fac190604f9ca580ef2eb8afc86692c60533b18d0ae0ccc648aceec14b9f26a7f4f73a00430e0cd6fceb29cd9cbe52de463532ffeab0cce64604b34f93692e5c10e06cd0317f0e0d03c80b3a2e12c672ce37790754ec30a92aa8a4e252737a3290d2ff0cc01447b1ad18b0e75a3ff518cdf153be6bf926dd90f6ee9841dd88cc074a05fa5632c410ca88000b6c100604ae08bd2a8e0d39e0e359c9d12e72ca7583a019b2876d0f48b27e46315a188511d8c12bd4dd12f5bbdc080ee52e44a0bf905d88716f69b01c06847a7386e16f30bf11e401af8b0da08d31041033a000366c01a0ed05b81a6364536b03aa0063680e1cf24498212f002d8e26600b18b2de4140720a62e034c61263081079886194cc0c00ee41d021c8c80ce6210015b90d61707d8c002074865eab478803ce18e00800175c2c9cd7052a71815a60e0d3346501804e080d7a751c2d1e4dd800720807d5b9e835e685c7207a4267d35dca06b7be6727d3523e1c326f6951dfeff709cdfad1923087bcf51d3187534e0ec0f180103411e86539ce244260780c15b6545f48d767bcb6d16cdc5cd190e385c4010e75a3310c3739f47c9084639bb2a6010030636b00e6b02310148d08cf45db155e86b1bd5f3aec785639d3381aa19dbc73378c4208631aa26c20ae47d800670e0e88e1f3d175cec080c84e09a1638f94d9d72caa19d2f7dffab3a73bbb8776177a95f42ac999c725e1cb09bbe81947c0a06cede2f1558c0f1c58dc391bb9a0003a44652a35d41095109001d6492832de77c73f66301be87b08f8359be0ac13e82c6bf07704468005a1b70800e942035d8277b5760142ee01b2fb6021c50468c11443aa08083817eead723c59775ff1de5584426781ed7788fc70b48f4621bc07a07c06bc4157bcc0705aae0815d85800e381838d07b763204bf6135c2075c76b26895e4520f1037d17746bc85003140010d540367720a2f1660fc7700160780b1977a664022a14761dd374f0b884a43b34c43e014b3355e4dc41dc52727b7e53658532225581d165003081076be701d093037ad777647f80055e414248806cfd67d803151952085536842485048f0155facd22ae3862079d52f1d605ff8454b67540356341a0fc00121d0016c4835fe777409b47663280d2eb002de67624278097a3818e40730a3c15209c61c31a824c165490f765f81a742be303a92254aa92389b62889303002ec6342033034ff6570829cd82013d589ffc118c40730e5e16abb0288ebb701b7534188086199481d1c708b1df0001de01609104570a88b0c944a645087c447046e418c8f8566ae9654a7085c6fe533e7368dc5a1022b40352f90612e6060348038e4f38301788159900f9ca880a4b20a0239056ba27183766de4055c79557e37078fb361143d830a2f40031679912a403adec73ed8575c027804b9b289e3480434a2170752050933683bc0034cb690b67532d1d87510291b0923202f50911769913e600034502747c79198e88f535092c1086f12128cc6950a2a8968bfb685ecb83b93726e5e5744f3d200f5980017e9035ab9952860861fc73e60d93ed3a105bad27dc49130ff07389254e05708f969e9c48ece01933737950f940f9a538f2be0032890017cd9977c69010690406139185f924059400c18d00bc471648e6096df456d2b096cf00597ac159510b65572e205ef86161bb13b2fc0017bf9011fc0022c209aa6f901001076d0627aabe41dd03203b28798c7482a06c889273980a8006e87c66d94095a3129201f291e09902737e90335409ac8999ca6d92a5f5203a73718623903b0f958f382944550802229944e406dbac903d64799c6d48a10069c45349c11509167080002209dc9899ccbc973ab499831f02c23209dec559d6af903f9e01b48b962f91699e0c60094d49b4e6173ae48976db09902c10137d9932dd002eab99effd239032c608609800319809aaaf99cab9940c8495612929662b29f1bd09f5a202f2bd09d89a67000e056b655a0061a005b35938fa10215990102d003103a449bf171aac97b1cfaa19a7464abd089a4f2628d497c12b005f29200dda968bfe18c1208005b3797afe83c3c990133b0a3ceb203ddd33d8a929a622a9f414a9a444494c438048c699bb779a229faa436e8140ec01856d670564aa38e61003ef07183113704a0925e0aa649e2a32c687a65ca024413a245fa216b7a8c4bca05e5a1a2ee57830ce770338aa778610038901a04a06aa2922c7662006f62011fb76086caa131809cfb8103457064b6c9a8b5399b5e10a9ba8975a266a7074a49f5f43eff81010ad5b800ff771f6568365842aa9a517fa73a1808909ccd409b252aabc212abda4905b41aa0b6aa68557a9953b902f2e83c30a79f133222f071260e532516502700c00ba989acaca919a5f901cd7a34d9e9128d3aadd4eaa4b57aade5e6019a416101511edef73ea28aa4a8804e0bb001259228e71a2bebcaae1c6a62a29901be900a8ea97a1e38af10a9028696affa6a65a9a819eb650196901a023b228d6925e1b2b08c11766167a89a610119ca970f4009f949a2183b062a800170dab1fccaa3c3ca320f842891512448952a3db8802cdbb2ed9a9acdf0017ce9033490a63f4080dc07ad45003d9257051abbb33ccba38757b26924a8f2922a66384fff497bb6aae9710900b37c89027bd920baa217e68804f3e255a058544f90b3de892625106e1d9b755e8ba969814e5fda3d3530b68962864e417c68dbb861d70c7e399a1f27b288092a5f5b04d3202152c60c90060539cb1768021804f0b78c16b867b40316f0a565b82d899b1983e1b88d0bb91900b3a3599a875b330e980447f6021e7603f535051a0bba88761a58f7b181cb18c3ca8477e3893500031de0266fa2b87c0aa4a70abbc99501c899013e301f82e53e8ef06239e6bbbf2b052a908d9d8668094876c76b0061574d9bd13d3ba0692580a519893888622a9730a6d47b7aa617bbc9659a19c00bd1e68f98e26133e01a202763a01b62eacb821e07bbff2efbbe58421a0630bf16730afdd70121e01655228408c0bed3eb1d8369a8fefb71115b1ae582554880c13990a32070b950c00a6ee102304071817186b0ebb8862a9626762cecc66c06a06a69a4a021b27f60c41769741aded7b22626c26029c2fdebb84e31bbef258549202f1ed65df66a04e5016d61447108802139acc34b6b623b5024a29a28e46a0994f0621a0018782b1b346284fc778d0fe0027f11c616908109f42cd8f72c6019c5fedb0ccc201d133a9dd2461e0930195aac59b3d8163805c6a831c68debbe265686f79b467e112e14026235b002d431c774dc7f2324c9a48aac0e18803a10c8827cb6c95586e7d59e7accc50920beb2571e8f588dffa563caa76c45cb77bc2f8b1a3550b86fac23e16223f7c17cae9661a4716fa5a0011bb0714457c7fa08c6385c7f3cfc3a01c840ac1c038d6b27afdc9ea4299aa8418eb53cbe55a017cb66436c168ac0e1668ac6185ac6181bd0a98356cc691c2edd430f59802934729337d91718370bd0fc81d3dc47353c0185d1b248278a12f0d0123082ddeccd497bc964d79ea749ced2760ab6fc5da846c1edbc01a41ba7548a6278e4140568cfa8521ac74238b287b02f769e009d9351dbaba55080d37c8476bccb3d87ac0ded14101dd1233800ec43c22c3b44ca99d1a2c95bf0910a3980ce55508a201d18231d6a303a9e8c21557f2a407e9100045025f00baa557064ff77d9a059a997b3dbaca3a02b6e6888764c45d6ccd040c818120002762d87dc4c01461dc29c31ce4aedb47c3951c4f0d4dd8505066068781c62cc50d5c296ad3837185bfd410b708741fc3d2ab95d89fc0434e299334d035ce997c1890767058292c84b09bdd072ed910050d777bdda797daa09c4b09ab19c16709ab5fdb434e0d4085c09c244bee77b683a2b738cbdaf362786b1e2a589fb5e810aa8841c2a4e300d2657d638e9d968cd97a259279d4b108a5a221b204a70add0d78ccd733d1876ddda3af0da117cac23b01f7c2a9a7662dbb5fd0128e0036e211cb051869a6600ce8c0432c6b1c35da7b86adc3f508ae112189c43ccbb969869b204b6703fff9d4ddd6e6bddc8291dcaab08711b7a19b6cbe09db488b18b74ddda7143d47a9dde2bcbb2380c00eeed14cbe914a5890082e51a0a60193740aea561c174eb55d6fadf001ea3216b00a9c016c70cd9850b1814370140f7c9452059b5703f328d935a19e1192a9a2c609f827b063b80a408ab7cdc5ac13880da2cdbe114e080ac7d504e31e2143d4fa941d167abe273a2e2a8b97c022000f40501312ee3325e09a15b0430dd98f81a6c3abee331ea01942b029b08bda9e2d24ef1a5935d03454e3cce0d0a09430c0286279dfde47b29e1a4299d729ed90283a40a0362a611de729dcdab5dd717d12a49ebbad4fbcd1930a6ee5d0362c9a51660e7b46e193be917ff6a78e126e2e77f3e6a41c600e5eb86407ee8fb8c8536c2e8557445021ce9142602c469d67a19e1a6899c9a1eda7170e52e407d08db34761818680be69af1d02f4c0416b00285d1c01daae6a9ee143f8aa81cc0c310fa03d7a1633a06c4f95d8a92e5021e76930460b707b7a2bd3e6a6f56be54d316c4aebacd20ae8cd8733e3701cf0b788047e9d0eeb67bd9b4d43e03712ee7553e0699a2d3769c239911de3fc83eff04d40fed129f2c62656ee6ea7ed40d0b9de36d2713d0005046ef2ae00329100eb80087dd670932368ff45eef06e0b77f0ee8bfce00870689b6b8c1e59a3685bb233ae2c10c7f3c338b6194b0020f5edd19cae2998ef1716eed6ee084ff1ecf4b36ec0b259edaaa7df2f4fa37e532d12dbfdea75c7fd002849828b20dd02daa206506001660f1bc570f7809f00037d00b005ff459066787a602fd83384872ccc72e2a6638f5308038ac50f90960d69e2ded2bdef5192fe78a900a63ffc50a0d03e5d24509e0d3744fd711ad8843c017dd4b5c6e4f783a1c9660b9ba1dd0006cc91693c10b7c9f02131011c7006d205ff4588768ecc6481360cc8e6f23cd30f5464ef964868f3a89d64acd1f13daf9589308a9e0d6a66dcde96927f107e64159ea2341f3b6562e795dd4b0fdf6a647fbde5c02e5319108a8029451036041d97bdffbd8b0d8c42f6e9e66004000130a27138b6591542e99c99565829016ff61a5c783a3d26e13349f0f85ca7cc86504609616ac0500c00f1e97cfe975fb1d9fa727308dc3a123e4a184480a61043101c0c00d2021862272a0114042e20d6e4373a5c6c26d0034323286b4d41411d1543466046102c625a4633681c3c0e0a6a62685975777f7b6577898f788e118395979997999e799c7e0a1885a8a11606761675b53f1e8fbdb70eab5a4fcf6fcf62b6cacac8cc56d864da0c54dcffe1e3f1f8eef6ff6aaa49a14548828391235a9861b4b98566cba0660522851a34c9d4a559154ab2256ae5c5171ebc60d0b2b0a942c90c2c2ae14350c10eb75a197b1663369328386a146c043040b165c210ee8b85742d0fde2b0ae9d3b16efe2b1a1ff87495f54a9f956f80124885011430351153c4869e18f1d2e5cacb826070087896b2960749b510a8ea1e5ca7dac11f288c992477aa91476eb9785026e6a16360cad0650ae8b190f0c2a97da845f8133b04bfa612953a72d124ef5fcd9ce8a15fd3afc83a15520e3461c0050003549e1a51d095624383bc70d29b6abde66446488ca90d3ba141417acf7880a5fc226c32890370561c3d3695ad8da183be3c738b8e32801eec8e57699d16ca6071a3d7a7e57af10a1967d3544508d2424b400b85e9ddcbb27be750c3cb2223a41a0383790cb0b3a5f76d1cb40e9a87b501928b29b50bba0c4010f00f19472439e163c842abd10f5498034d324ebc41300b02b68ffbe842e7123c515f07083bfb5dc4205a8eeba7bc282e218d1cb08c1f2da6b4806070300c224910100070a9dfccf42047028484332960220860e3fdc40c42ef1198dbd076078c0801a54a82c45c6486131a19e40bc4311486aecaf1428a374a3380500d0eb48184dfa86cf3e91543249379e3cf437c5786aa44acc34330f002ebd9c54832c129883030cfac10a865bc4b0cc50aee4a4a486170bc2e70c0e5e1b60ceb6ea4cd4c211f02c3005060baab59140dd608450651c6c26544485e56aca451ac50c1ef3e89174d21057c00083daec22008e67fb31cd80752cfb40455123d1c1cd3665cc47834f566db522f800c8d34093da2d80115cf7e4d38d0d98a449ff91c27e65469161fd1d28c3639155630d0f5be801006a9b4d6f05b22278e1052fca84a38f06fc19e423a4da61d25bd7dccc4f2a3774d061d5d7f8c3883145d89db7a477e1ddd3e59601886ed066ec35ace699ba9dd0827f1b334060789a9ac74384174e2f01176cb0e1612fc060a96111fc284dcc8cc5482ad81174730d36005204592ad60018b96489d8f2afab956da51780335896f9c89a72d6595f0ab3f6199129838e6168837b30fa68d0128880f088bd08030515a29e5a101830c8368314cbc87aebd77a4acf0d15c82eb9c6de6455dbdd4005ad55e604e2a6c9117df56d72c59df106f8d82959e8bb68c003f78c03889d06037115686b00787fc6ac41ff0c4ac870a4e3d75438353db1c77e8d6456e7746b564f4c3a43f4c104cdb511b9e76666df65eee68ae3d7c9dff632a1cd43f8cddbf55181061a2aab6c820cc2c0800312ff68a016151ee8240394b8122a12f00839adea722112dbc8a2c7b993996256dcca1ebd64e60604b46c3035b999ea50e73aae30c27c8b7143a30030bba618ec6060739f3e58f2a90f7ca3063ea081ef0e209ada64a14c3d79c7c75a5332e68928459b2bdb03d7b42e5a4d1089a1fb9ef870e6bd158570318aa892ec687730f6add033ba60070c0d30430ee40f03baf341657848aa0cb4c95c0340e3c21aa1831894cd64362a22bb4c97443b2ed15738c3e331c6d71528122b60e271c3ffecd6673b2c4ae50868fa8501b660b8f8c9cf843a68031a669019168ce74a22eb81a902d74638c691223198959ede66c7eca5ae8385c997ce3cd815d6fd9127552a21210b56bbf61d321f2981812ecea105477a21032c90873cd26049a510923e2fbadd0e1aa1b94ff246944624a52993183e5fed3119d8449e6a6009b040a6cf84b5b4a22171199573f8e016f07ba4d382691e621ad34a4b199a425478b466c2119ab3925529a9c936ef35516709504d2bfff5ca586aa88455fc5b3dcb898f2fae13a25f6827d150c8864a66e6987da3042eef79ae50aa4c01fbec493f6d85c7eee9ab270c50441f65f5c75d75e59b582398df168a8186866d0510fbe5ee82ff79422b5e83020228e6523049bb4634f46b7134c5940a54c69991946665d4e3c70cf04497baa14923140f537c6ac54bdc542a55d1a923bf30c60fccf4296d14aa25d94acb821df5a62e6804ab5e358223e409afc51169cc4c59900b9e546eb8222541bdd9cd7d4e09071a7a1445177a4bb0e2810f0fd3e923d5d1d3132ac404996dc15adb9a99a1118da11cc5122b068283bbe615b58d30004945075856ca8c94132a5f371b9100c596479c8d7d2c55302059dd39ed6a6e05ea7c367bd1ce86d329707dacd7603585d3a236afb9626d494dda08d20d46018c10e88a0c0acb95de364bb925e76ef3b082c2fd16b8c144eef21a0182411ed74a047b6b6871699dff287d03baa9e52b35b1ea545d2520b656352c4cd1b714d614d2b1e4a583087a3b56ca22459e907a430d2ae3288cbae3b36955b00a38a0231c88e3098dc86f9ef6ea541e9260032bdd6f01be1be0c61016966ed89667d7475f05cb81360e8e9f3a506061f982d6000554ef0e31d408d0daf8903909508e2831e2a6f6c4b616d82ed0aa4a866b9000cb5836f1cae033601102c032f2ec6a0a137ce3387020a7bfe4f1183cfb6301b020c809709bd7a09018157ccd0d1f4232166b709ac8046504c5a2c4083ee064434737cb591ea5a161dc522f932f603416efd8cc9c87fca9997715b6641a385dcc4eb5c9022e494105207202375cf1c606e8809f751217029aff58454e1e65231c906812e0895b552d63971f0d691f23b8d279e0f03a797cb578c2f785f5b8c016cec18b0a9c00da26f0da9eb1c84856a3c6153d6b0c77600d6b5ba3d8a9b7e82e377b0d69493396daa95667591137bf63b635d95e535cb4a2f591963c3bda1bbdb1065470ed28645bdb4fb24d23f05c10f27dfbd6216cf4801d11e1dca65bc18cdc1def3e3563f214a402154801070827d9f8dd3bda99556ec4fd2d8523ece4aa0675c4b717fea4967753766ef51bc4c95b827517dbdd58b320252a701215bca0e3ba0b3200444ef47a55da0025ef441468bb086fb25ce1552d37a4d15ab445045bd894a5014e746196c46e6c8229f839d075aa824e7cc20dffd22e7343937eed120c2835506cc4d36dfd7227d93dc6f29d39b3b05e8702f6ef1cbaf8c6486d2598145c207763bdb300c005117d9bd9002eb8b62ec401cb6bd03dd17897edd44585a52a9ea7ef75208b0ba2558b07cfafc430a2045fc44e83b1fa4098934cab4d2b6df3c927e63a72cf9a1ba01e4210723e15ea1367c2423f070c6862074cfbed9ad117c09eac0418109d28003ca44cac279d1a94affc1f8b857945bbf449371a560c3cf1e32d153f0e0d71c0d298e6f1c3195b3ccef7da49786180b2828196345dfb4d6f917ddce75ef7bc4fcbc6ed5f580a157ac3370e259a38ad432205fd2846699626e80c27d382e6385662777a4ca1beeafada4e324aff40519e8400214d006f6d0415b0147283b406a21476235d447096cc0f0054e00177000344a0e3ce8b0235e658c001e7840900288accfacedaaaa0063e2c04edc66e5c87f7ea6ebbfc857a982401b5065dea4ab662d0a8f66fb7726cac262bbdd0a74a12e9083e0599180b616810eb34401a26a04c9070fb96100e618ae534ef00b7662ddcc08054019fa0c9e51040cc3683e61aead2746cc72a50609222912cab0d686abc20cf00d8f00801edeeee8e0901600e1145156a446c10a0053f497a5c650a1b4311ce8da2b4f0b17c67a70a515b0e116bd88c96a8af763c21f416a0fffaefdfde70459e505d4ad00059301325618822a1110ec813f950b612a0cd20ffe5012b05a232d08558b120fe700d60f16f508d08b5c0166f31ee2e0282b084127911c630622d3cf11329a08d7460932cc11240c90a07cac7328c1e6ae00155a003228ae2c0b0519c6fc8e689faaa1161f80eeb384c0b58ed0da3f0055f6cb69a30cb6c400511902dc81194845164d4511d956a057d3105136bd386e9291e3001d08bdd9e9115332ab900c01f03b19cfe8e0308c1cfaea30559c31c5b031411309a462b9ad88ffd1a521cc7118e28d2a324b2207c5222a6300a8f0db9d8005cd08f0fbc10b8447224cfed43fcd1fa42ef591aa03606a12505424e805226e9a43786911412620372300268a4553c91222bd2643c491d9349024221017f5118fdff90ad1830b98a6f011a0c240d71247fad964eed6fa6b2ef8e4f6ae86d10028218bbc66c5a052845c16d72b0116a841cd3322de70346de68002c0104363336a4e7225b7022deab2e65d01453328c98b2b2f051e74872be4c32302f411e438f300bf32ac5442ba81081e4e327e7243245a111e48a1220b26c289332074d6b40411d37d3bdccf222b5263127e1b88e721a4b1397d00cbd9a5235d347349b8212a45230836d36a5c62a57a03d26e0c320c187747337272237d5b320fa413d2192389573331fa25b0e013935d3bd2ce0071ca13911816b2c070d8ecb2ed9803a0f091529eb1efbb28c06c03bdd2bf434c0053640042a1478ac3201aec03c0f2140dbffb212de5238dbb33dffe00042a04de4733ee97339b1c102dc10015c233921f40736c0be8002331168a83acbcd00c0058890031474151b253a15aa1a3513006233d8348142c513786a28015480e912531d19412d43543105d40d4af40134e9938853025454df12e008ab014693132a522228ca742182d0b82ee91d3f0b25ddc7164232e7a25347f5ae76d2f14be3f4768e8f0098d42a00a14cec906b28d2bd843244e70a4b01200442a00462c34b29134c478e91ca41085eb438e540c9aa213329320839cb4d8f6d47438f78b4851dec74d33a8d48d391330f74858e6f0700b51f4ac0b466b027f5d36b40a04a21d22d5f2404dca00456005223f54b95d33e91fff4cc1a152b7180020c156cda8e0846a053d7740d8a2929da0c4e63a0ef58627e5cd14e55f5b3c46b9394934f03674263553c493404268014d8cba3f2734fdd72388b735897a751010006e84357bdd4587f680eca620394150610605a39730efc67599b953e3964adb6ca843eab33b08e13dc0d5bc1b5d386a990c6b555077349d3f52ad8b5533d497ae0d5bd40000328410588754d3fb42d43e000dac80d36935e0b0259fdce0566411040563f65f4cc0ee01f70600016b6112a890cbad55b0b7492fa2e912ad66231564bf2b407c8d555dda7013ab64901611a62202d45c66ca6f51240200ed06858e9556617e20f80b3f19c0a0ded417f02e10198354629ff0dc7fc010483965c8173298c56d3c44cbe9252692d806f9d567085106a8bb55c8f660736005d2f146b71406b8b5557d3e820a6b512f4a3db0a82708e80490e770ec0241068b553c9155334651660406ba5160e4a486f23e7680b94739ba55c28697031168550482a57b4ef1640132cb4494b4367217745e11233db5207f22171ede54d2cc0061ca0065eb6584244043c37044c776755c85a000106325374e1a04557778452154e8b0f2c07b7766dd71f37e9f1826d4265d5677f1778e7aa2d00343f8f3464882f6c1dc0001ce06547ee3312606a7cb75921f74dc6c22a4200680d172a7680c28cf603467134f9b1f8e64c9238b27ca1f66f56746a5f954219ff17103aa004a435465bf564a7707ea7b613d6f6077c8703f4f7515fb75afef76d4377398dcf05aca2044ed76035b5e240a5ad903683b1c8796690022a789caa3181a87249afd61f98554f1736756b540a0a9503f5c1160c400e4443061c2002fec7853540533a987a05780ec6426a00e18037f68a17785b84a669a7f301e1206d2fd70d7a14fd1ac005781786dd7761f9b33fa1f845e7372a9ec52c2445425d400664c0060e206dd5e38b4be380c5580e30a086fde00170d8bd00f207aca3c2ac8461abd56267c06bde380e14d8a96af6011b8683b11606a4b560d1180e8eb03bfe1839b1812ac8c236f8336936e0905780030a0e34aa62561f975cc7651f26ffd98ced7686ebc00236193358638285ea93415903fa6e9a45f933aa4289a9c671493687c31603aae14661e31e1a862ccc822532a5900f598b1b350496e733488f346020805d190283070674408031997b97991de221cf3c996923d69a075a0faab244da8313e1754f6b361ba32040a9edf83680f49e9491d04c92496f05eecc0d30e051fbb791631892e320699ab49205b8ccba7729a673008aab8739cd85095ac1d06c16a866089aa443d7940ef86d08a2209cf72fa2c90203fa87c312e090656005f47710fc7544e259984140a02986008207689d180f68d44ae6a11158da4d2b362d60daabe9801e3be234c4013d5f8393e840d56abaa78bf70e16604225fffa90f1870b885a0638a0033c6c4a682facaee58c39938eabc5984b1a75f3e008529a7da8efcd42956979f4ab1b3b85b1f2160f3040bb86ce6aa09a53980396b5a7cbeca2815a5aec2d7f12c0063a8049baa3f170c7736ff87d6958aa9139dd0649000e7b40af956fd3e0871dfbb11889e9ea702b2d1314620001aa786268836a2680952d074ec8a2a88d1a877a49d570808146e670fd178c91d9bdfefa07dc9aa4715816f18143a2f60d4ae832c07706cc11b7619aeb9c732bd9422659c1158ae049f9c005ae82567b1abb23d9908b7a36d4b94c50044bc045ba018098c36a6a6278b0e3e0065b9b5cad381ff2ecabbc86995bdab66ffbbccbc9003c813147ffa115de9b0ae4bbc041167a6ee9a2977b05d4d906ce8ee0007c573e23538239a43321b0711825cb85020027254e55c227bcc207fa44277731490140a8e0013a005a3e369c27810e1a66b965a080d62f02f69787d4c32aeedab5dfa4628e7998a5a25cc0c50534c0aa51d5925e7ac7ddc70d54e599e0a23ba8a10442004c7c769b73530e6c10a8a3450454408bff20a93f86616cd892df84f4b61b813f63a3f719ccc39cc2c71c8b143518db22475ee101f860164070b207c06f8bf99067c3ec8ea0441d355fdd0469fa00cbe9f9075620aa439d673dc3015337a1c0f5b8c41cd18fc6798ab14ea6a00af2a7515719182d8703ceaca8b5b8e0fee188d1e3ca05ffdba9db67d885d9d5553d9a3b2bd95fbd59928a1c195d4a60400b34740472dd32e3c00044c0c97f9551bddd0db654a93d03952d66aa3973c0477d039a54b5f7948d28e993dbaad99d7d52524405a23d7e11c0163914dbe9376c99c667c31dd8f53c3d12dc67657c8027d90fda7d8a27c5c89c96d30c9dde45596465fd08243bd71befaf1320882e373d08d8dcedf6a929265d3b600242d694bde4e1213ee2f977e2fb4ed13dd12c7992b28f000e08408e5d38c11b80d8537d94af7cd5de6821d2bd5998094b66179a7748615e5e7c3347e6bb72376432d0264353a7ad8cd0c306153c99712c501f8060db72e96f076d95a5a2c0459f993ed8bee6ded3f3217fff7bb480a30400e3072ae564e30079c73d90415db0477e1f3a38e83db59cdca448f11eed432f3805349472d3bde3821a18a9803ae160099fb7a2e5dc199b0eecda6dddf7d0a502e7cbe8ec617a01c67c812cd3558eb32d5520df7564237008f2f583914b4f6ced4005046110de7c3e76a0f07129f45f3e9ada84b412ba2d419402365c4aa8e0239ec6e6276505703062b476c5eb401ac404066c7f3e727fb7346001b07fc781138afb5c2df3dd15d2010ce627f9450403944f9ead11ad5992a74b863570dffa9b25f477dffa532296159633f7957380bb54773872f818087ec221b158d4ac12ca95cbd6088d7a3d00c038343c2613046244f982138084b56c3effa3d3ea35bbad5efc76ee399d5e33c0f2888104e4071848080e1016527d64242a66b050d531b9b84444604cae18000802d4987118e07075c5807dc5e0006cd4a9aeb2cec1b50abdc2ceba19709494c0e0f0f58150fdea084a0ce800ccb0b0202a7e203bbaad6c884cbe50533f500058f8a2d56c758d8cc4888f8b3bd39ea3d7c9a6d3c1adb317a9703ce4e250086fff6cfc6e0e501d23fb2050208b1933b2b9c160c3c6b46a34a2fcc2c0cd028e70e42e8e32076f23c78eae86bcf3e8e256bd7b82f21151c10f20b296c86608d09826818885115ed0a0e1c347144d6b2c58c078118c4c8f468f7a5ca074a9060d21376ab8a5c7a4cf32ff5a1a3428606b0b4cff6d564ca3f1cd4b8f93557e06152a8e5451a46edfb65ad0b4e98eba1adc2e50910b06020a65ab5a05f052ab80162da44c61c321014e14230a1b96f247471ba06bc18c2385ed2cdcce9eeb68a8bb6303811f4fe1e5dddbf7af04ce810bc284fcb76d19153412b1807cb8ec2f371b806a0e4ed4f5e7e2c68dc8d2408074aca3a9ebc5e0d53a0d150e5c0ff7e9bd6681057ede23ced94145b870dac7cf1fbf6bdaed3c7a134648271ef8bb76370422ba58b1c23b9df1e4359b879e8003429540080f64119d30f295219e779cd42106833fd480d01cfefd371c811b72889a81074ea02060e81850a20135ac50840116a051e2696750314a8614c400942c2f7698a3ff8e6570b042072046c7cb84aa94a0c289402159c31d2a24c0412a68b0d81f15039022d4084a2a69800a12edd8a59746f418029085b406612b2ea8a0240e562450830a4676c401863462340202779858831c5ff2d92593072658883f43d662a61918d4009447e3098503505996a824a17d526a1c93083e8043908404b89101a57514e34548ae90010aa726da5da5ab12c8c113086a4a66a7ac0e4185a63502b5c8228d6c42abafc525d04107088628eba4bffe900d92ba2ec2cc0c31cc8aacb4b36880c101078c29e4b1c826902bb389109455afd3920b0f062e3470c08fc56a5bae1916a8f0ed408319b4adbbf7a6c1c4062e88a06e0730042988aaf816a1e4ffa928803bef605b454bb0c343ac70ee0613bb80c10621004c88205e3d2cc40e061c0cae4b596d2500361da37ce8c40b45527112065020dd7429d7e003c2221356b2612dd89b72b9162fc4d0240d55c8dacc952ec681d26fe66901194418ac0832d7218658cf3e4b0b8d033635448d0f0765b220ab4a28cd810a0b1090c08a482a2a04c822532d853047638db20b3b707d53353e205018260baab02aa2492a09d49e3f74eba60606f89081b3ba21e6872f57d74d2b13793bc4d3ce5350d15ae0c86aa002db510a81650d8f175675760d57eeeb0e4d08ad77632c6c2e45e7007c0efa061cb8402a112b02f058ea72f3d37aca4c0c2dfb6d23d46e7b7dacca6376ff85fc2059047dc51b9f72255dbfc037e4913f5f29d3861621a115d867ef7302db3b84426e9155cdb91004b8b0aa91a04249baf5ca8e9e7e9f0b98ed44a623df0fc0223bbec1a4790bc204152c50a2c3f9c9009549d4ef80c7bf2409d07f395a4c938c942a0eb00d2495c0894efab6b3ddfc6572e6d841aaf0528734cd61455730c093aca081472929776c58070435a80a02982d696bb340fda0d6b604ac0027b8d10d0acd429bb6b16329384a03012418432bc2700d0324a00f91623a174cac180d5c13d438112c46c4e684aa53e119a0b81da5a0410364bb5f5de650831a56460818b0621b0880430bf4b08bc6c9460df0f7030320517454f81e625af38b22ff9661035c34030108104821842e7a47c2610d9a62942a20c1906e40d2b6a628c87360493d3f78d3f4ae873dfd95e14469d09200dd44c3df994e94a1030a1ee141004e78a2151a80e42905d4420a598032c9fa050301b01f2a40ca4479c2c02b38304921b0b2064ffb4115ef501a59a60128aa8487279454cc87196e9944085fa20a373ac2e14987f190611920c5060a72c49a943b67a58052050b28294542b090917ed14b22dcf0514011e52af9788648ade1370c3d479bb8c4cf8755e137384c45f4380003374888382562030cdc08a37db24109d7bce8c3969480bc38d40dc43ce4367fc20694aec113166569e5f08425792205a7e8c8224fb3e7471499b4596e069869515be74fd6b90b964d35de3ea850d3a962b55cbf186756bb8aace97935acd3020057c56ad6b3a235ad6a5d2b5bdbead6b7c235ae729d6b8ee048d7bbe235af7add2b5ffbea572298922381fd2b4b07ab0ac3d62108003b),
(2, 1, 1, 'Prova oggetto', 'oggetto di prova', 'image/gif', 0x47494638396186000f00840000000000ff6600ff6804ff6a08999966ff74189a9a689c9c6a9f9f6ffff1e8fff3ecf7f7f3fff6f0f9f9f6fff8f4fafaf8fffaf8fcfcfaffffff0000000000000000000000000000000000000000000000000000000000000000000000000000002c0000000086000f000005fe20208e64699e68aaae6cebbeaf24cf746ddf78aeef7cefff3c9124402c1a8fc8a4728994109ed0a8744aad5aafd8ac44c8ec7abf4767764c2e9ba95bc010cc6e87cff0b83c9a5e4366838023709740887d0a010278013583857d7f7c79058262113307040692943311040f04359a9732939b4f0d9f12a150a491120b9ea39c34a5939c5c7a450cb57b010382b944bdb744c0b5c1c3bbc103094462a204a4ccce52cccd4f9bcf049193d0ae91081299d2d8d3aed4a84f75beb6b58a8012b9bd46c2bf7c328bbaf59096d695a0ad07629ed636914a85c9d3c06b12440914c7d0da2c35e888edc905ec9d3c621103dca25864c03d72511c9613450a4ab5910465fc7d43e94ada2695e5408a3b374f469e89448c054264331d11423d7319b3576499947da610f2dbd46913d2532d594e53c54a64c958e668b9d90ae6df9caf60add0e44a9689d7b068d18e2dcbf64ddab761eb00994bb7aeddbb7661e8ddcbb7afdfbf224200003b),
(3, 2, 1, 'Però1', 'Prova accenti èàùò1', 'image/gif', 0x47494638396171000f00840000000000ff6600ff6804ff6a08ff6f109999669a9a689c9c6a9f9f6ffff3ecf7f7f3fff6f0f9f9f6fff8f4fafaf8fffaf8fcfcfaffffff0000000000000000000000000000000000000000000000000000000000000000000000000000000000002c0000000071000f000005fe20208e64699e68aaae6ceba6512ccf746ddf78aeef7c5f8b918070482c1a8fc24861c96c3a9fd0a8744aad4680c8ac76a8ac7abfe030f40a086ecfc6ae78cd6e2fc9e6472c21900d02f2c843d8182e027d427f5d103207050686883210050e05348e8b31878f4b0c9311954c9885110a9297903399879058804381017f810309a9827811047a015d960598b9bb4eb9ba4b8fbc058587bda28508118dbfc5c0a2c19c6fa8727dab7f797bb1aca97f834b9e9aa1c08994a1076ac2d28f989d8c92edc41196eccff6c3a7657caa7eb17fdbadfae1f225adc9314c4cd4897a848ed9ba87090b342c380e219c7d42eac4b8e30a96c6081c05466b524e5cb84d91381e95dcb41022304fa0f0d95b394d1f9a9b49dce8dc6905154e346a780a1d7af127d0a14885c2f1c1b4a9d3a75069bc984ab5aad5ab294200003b),
(4, 1, 1, 'Pero', 'Prova2 accenti Ã² Ã¨ Ã  Ã¹', '', ''),
(6, 1, 1, 'Halò', 'cioè è più', '', ''),
(7, 1, 1, 'ultimate', 'ultimate', '', ''),
(8, 4, 1, 'a', 'a', '', ''),
(9, 1, 1, 'ciaÃ²', 'piÃ¹ menÃ² b', '', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id_rating` int(5) NOT NULL auto_increment,
  `id_prodotto` int(5) NOT NULL,
  `id_utente` int(5) NOT NULL,
  `rating` int(1) NOT NULL,
  PRIMARY KEY  (`id_rating`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dump dei dati per la tabella `rating`
--

INSERT INTO `rating` (`id_rating`, `id_prodotto`, `id_utente`, `rating`) VALUES
(1, 1, 1, 5),
(2, 1, 1, 4),
(3, 0, 1, 0),
(4, 2, 1, 5),
(5, 6, 1, 4);

-- --------------------------------------------------------

--
-- Struttura della tabella `rating_feedback`
--

CREATE TABLE IF NOT EXISTS `rating_feedback` (
  `id_rating_feedback` int(5) NOT NULL auto_increment,
  `id_feedback` int(5) NOT NULL,
  `id_utente` int(5) NOT NULL,
  `rating` int(11) NOT NULL,
  PRIMARY KEY  (`id_rating_feedback`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dump dei dati per la tabella `rating_feedback`
--

INSERT INTO `rating_feedback` (`id_rating_feedback`, `id_feedback`, `id_utente`, `rating`) VALUES
(1, 1, 1, 1),
(2, 1, 1, 1),
(4, 0, 1, 1),
(7, 2, 1, -1),
(8, 5, 1, 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `servizi`
--

CREATE TABLE IF NOT EXISTS `servizi` (
  `id_servizio` int(5) NOT NULL auto_increment,
  `nome` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_servizio`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dump dei dati per la tabella `servizi`
--

INSERT INTO `servizi` (`id_servizio`, `nome`) VALUES
(2, 'Inserimento prodotti'),
(3, 'Rilascio rating prodotti'),
(4, 'Rilascio feedback'),
(5, 'Rilascio rating feedback'),
(6, 'Modifica prodotti'),
(7, 'Rimozione commenti'),
(8, 'Eliminazione prodotti');

-- --------------------------------------------------------

--
-- Struttura della tabella `specifiche`
--

CREATE TABLE IF NOT EXISTS `specifiche` (
  `id_specifica` int(5) NOT NULL auto_increment,
  `id_prodotto` int(5) NOT NULL,
  `denominazione` varchar(50) collate utf8_unicode_ci NOT NULL,
  `valore` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_specifica`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dump dei dati per la tabella `specifiche`
--

INSERT INTO `specifiche` (`id_specifica`, `id_prodotto`, `denominazione`, `valore`) VALUES
(1, 1, 'Peso', '1200 g'),
(2, 1, 'Colore', 'Blu'),
(3, 1, 'Altezza', '50 cm'),
(4, 1, 'Spessore', '5 cm'),
(5, 1, 'Altezza', '50 cm'),
(6, 1, 'Materiale', 'ferro'),
(14, 1, 'a', 'a'),
(15, 1, 'a', 'a');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE IF NOT EXISTS `utenti` (
  `id_utente` int(5) NOT NULL auto_increment,
  `username` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_utente`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id_utente`, `username`, `password`, `email`) VALUES
(0, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.it'),
(1, 'ricci', '083d2182dc8fdf0834b112256802ae2a', 'francesco@ricci.in'),
(2, 'franco', '', 'franco@troiano.it'),
(4, 'as', 'd41d8cd98f00b204e9800998ecf8427e', ''),
(5, '', 'd41d8cd98f00b204e9800998ecf8427e', ''),
(6, 'asd', 'd41d8cd98f00b204e9800998ecf8427e', ''),
(7, 'qwe', 'd41d8cd98f00b204e9800998ecf8427e', ''),
(8, 'a', '92eb5ffee6ae2fec3ad71c777531578f', 'c'),
(9, 'franco1', '922867efb87012983360b24fa7b24d7c', 'email'),
(10, 'jhg', '3994b0f776913f8934f0a5c633371b2f', 'jhg'),
(11, 'oiu', 'e3ae9aac5e647161a3ea7cf57674a59a', 'oiu'),
(12, 'poi', 'd6e1c05c8a81c2ae74c7aedea5ec92c1', 'poi'),
(13, 'lkj', '48e2e79fec9bc01d9a00e0a8fa68b289', 'lkj'),
(14, 'mnb', '62cd43b670f7e4ec902b5c7acb4d33d5', 'mnb');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti_gruppi`
--

CREATE TABLE IF NOT EXISTS `utenti_gruppi` (
  `id_utente` int(5) NOT NULL,
  `id_gruppo` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dump dei dati per la tabella `utenti_gruppi`
--

INSERT INTO `utenti_gruppi` (`id_utente`, `id_gruppo`) VALUES
(1, 1),
(2, 2),
(4, 1),
(5, 1),
(6, 1),
(7, 2),
(8, 2),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1);
